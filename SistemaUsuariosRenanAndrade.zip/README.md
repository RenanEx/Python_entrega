# Sistema de Usuários - Renan Andrade

Este projeto é um sistema simples de cadastro e login de usuários utilizando Programação Orientada a Objetos (POO) em Python.

## Funcionalidades

- Registro de usuários (com nome, senha, email e idade)
- Login de usuários
- Listagem de usuários cadastrados

## Execução

```bash
python main.py
```
